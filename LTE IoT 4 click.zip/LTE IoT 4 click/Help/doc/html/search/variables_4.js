var searchData=
[
  ['stop_5fbit_81',['stop_bit',['../structlteiot4__cfg__t.html#ac4c14aa578a0012f2140c35dba362d6c',1,'lteiot4_cfg_t']]]
];
