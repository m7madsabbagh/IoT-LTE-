var searchData=
[
  ['sim_5fapn_52',['SIM_APN',['../main_8c.html#a25b20478f760ec79e85a62f20b638adb',1,'main.c']]],
  ['stop_5fbit_53',['stop_bit',['../structlteiot4__cfg__t.html#ac4c14aa578a0012f2140c35dba362d6c',1,'lteiot4_cfg_t']]]
];
