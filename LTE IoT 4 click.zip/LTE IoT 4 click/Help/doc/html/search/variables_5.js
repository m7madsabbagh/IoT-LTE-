var searchData=
[
  ['tx_5fpin_82',['tx_pin',['../structlteiot4__cfg__t.html#aa7a940d4461591c0d821c67e192b90c9',1,'lteiot4_cfg_t']]]
];
