var searchData=
[
  ['wait_5ffor_5fconnection_97',['WAIT_FOR_CONNECTION',['../main_8c.html#a4c621a3838b46b2c67cf3f2d9778fffe',1,'main.c']]]
];
