var searchData=
[
  ['data_5fbit_9',['data_bit',['../structlteiot4__cfg__t.html#a885a893e6095925f7d9e53bb4ab97c00',1,'lteiot4_cfg_t']]],
  ['drv_5fbuffer_5fsize_10',['DRV_BUFFER_SIZE',['../group__lteiot4__set.html#ga62e1bb900d523c1b37584e2fc2f3aafa',1,'lteiot4.h']]]
];
