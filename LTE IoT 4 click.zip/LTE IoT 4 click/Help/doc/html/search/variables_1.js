var searchData=
[
  ['data_5fbit_77',['data_bit',['../structlteiot4__cfg__t.html#a885a893e6095925f7d9e53bb4ab97c00',1,'lteiot4_cfg_t']]]
];
