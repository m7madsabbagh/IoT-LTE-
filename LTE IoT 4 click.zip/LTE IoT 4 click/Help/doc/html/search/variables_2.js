var searchData=
[
  ['parity_5fbit_78',['parity_bit',['../structlteiot4__cfg__t.html#ad76f6283ed88037a8e5abe4f751d6797',1,'lteiot4_cfg_t']]]
];
